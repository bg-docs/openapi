# interface

**反馈邮箱**

Email: <a href="mailto:api@bg.exchange">api@bg.exchange</a>

**请求地址**

HOST: `https:api.bg.exchange/hk/`

# interface2

**反馈邮箱**

Email: <a href="mailto:api@bg.exchange">api@bg.exchange</a>

**请求地址**

HOST: `https:api.bg.exchange/hk/`

